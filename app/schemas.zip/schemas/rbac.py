from typing import Optional
from pydantic import BaseModel, Field


class PermissionOut(BaseModel):
    code: str
    module: str
    action: str
    label: Optional[str] = None


class RoleIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    description: Optional[str] = None
    permission_codes: list[str] = Field(default_factory=list)


class RoleUpdateIn(BaseModel):
    name: Optional[str] = Field(default=None, min_length=2, max_length=100)
    description: Optional[str] = None
    permission_codes: Optional[list[str]] = None  # দিলে পুরনো সব বাদ দিয়ে নতুন সেট বসবে


class RoleOut(BaseModel):
    id: int
    name: str
    slug: str
    description: Optional[str]
    is_system: bool
    permission_codes: list[str]

    class Config:
        from_attributes = True


class StaffAssignIn(BaseModel):
    role_id: int
    branch_id: Optional[int] = None  # None = store-wide access


class StaffOut(BaseModel):
    id: int
    user_id: int
    role_id: int
    role_name: str
    branch_id: Optional[int]
    is_active: bool

    class Config:
        from_attributes = True