import random
from datetime import date, datetime
from decimal import ROUND_FLOOR, Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.database import get_db
from app.depends.deps import get_current_store_member, get_current_user, require_permission
from app.models.all_models import (
    Branch,
    Customer,
    Medicine,
    Sale,
    SaleItem,
    StockBatch,
    StoreMember,
    User,
)
from app.schemas.sale import (
    AvailableBatchResponse,
    SaleCreateRequest,
    SaleItemResponse,
    SaleListItemResponse,
    SaleResponse,
)
from app.services.unit_service import (
    load_medicine_units,
    load_unit_map,
    money,
    price_per_unit,
    resolve_unit,
    to_base_quantity,
)

router = APIRouter(prefix="/sales", tags=["Sales / POS"])

# NOTE: role-column ভিত্তিক (StaffRole enum) permission check এখন বাদ দেওয়া
# হয়েছে -- সেটা পুরান system যেটা আর StoreMember.role এর সাথে match করে না
# (role এখন custom Role model, StaffRole enum না)। sale create করার permission
# এখন app/depends/deps.py এর require_permission("sales", "create") দিয়ে চেক
# হয়, নিচের create_sale এন্ডপয়েন্টের dependency-তে।
#
# ⚠️ verify করে নিন app/core/permissions.py এর PERMISSION_CATALOG-এ module
# "sales" এবং action "create" এই exact নামেই আছে কিনা -- না থাকলে সেই code-এ
# নিচের require_permission("sales", "create") কলটা বদলে দিন।


def _generate_invoice_no(store_id: int, branch_id: int) -> str:
    suffix = "".join(random.choices("0123456789", k=4))
    return f"INV-{store_id}{branch_id}-{datetime.utcnow():%y%m%d}-{suffix}"


async def _get_available_batches(
    db: AsyncSession,
    store_id: int,
    branch_id: int,
    medicine_id: int,
    lock: bool = False,
) -> list[StockBatch]:
    """FEFO order: nearest expiry first, no-expiry batches last, oldest-received first as tiebreak."""
    stmt = (
        select(StockBatch)
        .where(
            StockBatch.store_id == store_id,
            StockBatch.branch_id == branch_id,
            StockBatch.medicine_id == medicine_id,
            StockBatch.quantity > 0,
        )
        .order_by(
            StockBatch.expiry_date.is_(None),  # batches WITH an expiry date come first
            StockBatch.expiry_date.asc(),
            StockBatch.received_at.asc(),
        )
    )
    if lock:
        stmt = stmt.with_for_update()
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def _serialize_sale(db: AsyncSession, sale: Sale) -> SaleResponse:
    """SaleItem-এ unit_name column নেই — unit master থেকে নাম বসিয়ে response বানানো।"""
    unit_map = await load_unit_map(db, sale.store_id, {i.unit_id for i in sale.items})
    return SaleResponse(
        id=sale.id,
        store_id=sale.store_id,
        branch_id=sale.branch_id,
        invoice_no=sale.invoice_no,
        customer_id=sale.customer_id,
        customer_name=sale.customer_name,
        customer_phone=sale.customer_phone,
        subtotal=sale.subtotal,
        discount=sale.discount,
        total=sale.total,
        paid_amount=sale.paid_amount,
        due_amount=sale.due_amount,
        sold_by=sale.sold_by,
        created_at=sale.created_at,
        items=[
            SaleItemResponse(
                id=i.id,
                medicine_id=i.medicine_id,
                stock_batch_id=i.stock_batch_id,
                unit_id=i.unit_id,
                unit_name=unit_map[i.unit_id].name if i.unit_id in unit_map else None,
                quantity_in_unit=i.quantity_in_unit,
                quantity=i.quantity,
                unit_price=i.unit_price,
                line_total=i.line_total,
            )
            for i in sorted(sale.items, key=lambda x: x.id)
        ],
    )


@router.get("/stock/{medicine_id}", response_model=list[AvailableBatchResponse])
async def get_available_stock(
    medicine_id: int,
    branch_id: int = Query(...),
    current_user: User = Depends(get_current_user),
    member: StoreMember = Depends(get_current_store_member),
    db: AsyncSession = Depends(get_db),
):
    """Sellable batches for a medicine at a branch, FEFO order — for the POS item picker."""
    return await _get_available_batches(db, member.store_id, branch_id, medicine_id)


@router.post("", response_model=SaleResponse, status_code=status.HTTP_201_CREATED)
async def create_sale(
    payload: SaleCreateRequest,
    current_user: User = Depends(get_current_user),
    member: StoreMember = Depends(require_permission("sales", "create")),
    db: AsyncSession = Depends(get_db),
):
    """
    POS checkout — creates the Sale + SaleItems and decrements stock in one transaction.
    If an item doesn't specify stock_batch_id, it's auto-allocated FEFO and split across
    multiple batches if a single batch doesn't have enough quantity.

    Unit: প্রতিটা item-এ unit_id (Box/Strip/Pcs) দিতে হয়। Stock সবসময় base unit-এ কমে:
        base_qty = quantity × conversion_factor
    unit_price = "ঐ unit_id-এর" দাম। না দিলে MedicineUnit.default_sale_price, তাও না থাকলে
    batch.sale_price (base unit) × conversion_factor।

    Box/Strip (base-এর চেয়ে বড় unit) auto-FEFO তে শুধু পূর্ণ unit একটা batch থেকেই নেওয়া হয়
    (এক box দুই batch এর অংশ দিয়ে বানানো যায় না) — এজন্য SaleItem.quantity_in_unit সবসময়
    পূর্ণসংখ্যা থাকে। ছুটকা stock বিক্রি করতে base unit (Pcs) এ বিক্রি করতে হবে।

    Permission check এখন require_permission("sales", "create") dependency-তেই
    হয়ে যায় (owner-এর effective permission সবসময় {"*"}, তাই owner block হবে
    না) -- এন্ডপয়েন্টের ভেতরে আলাদা করে কোনো role চেক আর দরকার নেই।
    """
    branch = await db.get(Branch, payload.branch_id)
    if not branch or branch.store_id != member.store_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Branch not found")

    if payload.customer_id is not None:
        customer = await db.get(Customer, payload.customer_id)
        if not customer or customer.store_id != member.store_id:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Customer not found")

    sale = Sale(
        store_id=member.store_id,
        branch_id=payload.branch_id,
        invoice_no=payload.invoice_no or _generate_invoice_no(member.store_id, payload.branch_id),
        customer_id=payload.customer_id,
        customer_name=payload.customer_name,
        customer_phone=payload.customer_phone,
        sold_by=current_user.id,
    )

    subtotal = Decimal("0")

    # --- medicine + unit আগে validate (stock touch করার আগে) ---
    medicines: dict[int, Medicine] = {}
    for item in payload.items:
        if item.medicine_id in medicines:
            continue
        medicine = await db.get(Medicine, item.medicine_id)
        if not medicine or medicine.store_id != member.store_id or not medicine.is_active:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Medicine {item.medicine_id} not found",
            )
        medicines[item.medicine_id] = medicine

    unit_map = await load_unit_map(db, member.store_id, [i.unit_id for i in payload.items])
    mu_map = await load_medicine_units(db, medicines.keys())

    for item in payload.items:
        medicine = medicines[item.medicine_id]
        ru = resolve_unit(medicine, item.unit_id, unit_map, mu_map, purpose="sale")
        factor = ru.factor
        default_unit_price = ru.medicine_unit.default_sale_price if ru.medicine_unit is not None else None

        def _unit_price(batch: StockBatch) -> Decimal:
            # দাম সবসময় sale unit অনুযায়ী (per Box / per Pcs)
            if item.unit_price is not None:
                return item.unit_price
            if default_unit_price is not None:
                return default_unit_price
            return price_per_unit(batch.sale_price, factor)

        remaining = item.quantity  # sale unit-এ

        if item.stock_batch_id is not None:
            batch = await db.get(StockBatch, item.stock_batch_id, with_for_update=True)
            if (
                not batch
                or batch.store_id != member.store_id
                or batch.branch_id != payload.branch_id
                or batch.medicine_id != item.medicine_id
            ):
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Stock batch {item.stock_batch_id} not found for this medicine/branch",
                )
            base_needed = to_base_quantity(remaining, factor)
            if batch.quantity < base_needed:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=(
                        f"Insufficient stock in batch {batch.id} for {medicine.name} "
                        f"(available {batch.quantity} base units, requested "
                        f"{remaining} {ru.unit_name} = {base_needed} base units)"
                    ),
                )
            unit_price = _unit_price(batch)
            batch.quantity -= base_needed
            line_total = money(unit_price * remaining)
            sale.items.append(
                SaleItem(
                    store_id=member.store_id,
                    medicine_id=item.medicine_id,
                    stock_batch_id=batch.id,
                    unit_id=ru.unit_id,
                    quantity_in_unit=remaining,
                    quantity=base_needed,
                    unit_price=unit_price,
                    line_total=line_total,
                )
            )
            subtotal += line_total
            continue

        # auto FEFO allocation — may split across multiple batches
        batches = await _get_available_batches(
            db, member.store_id, payload.branch_id, item.medicine_id, lock=True
        )

        def _whole_units(b: StockBatch) -> int:
            # এই batch এ পূর্ণ কতগুলো sale-unit আছে (base unit-এ factor=1, তাই = b.quantity)
            return int((Decimal(b.quantity) / factor).to_integral_value(rounding=ROUND_FLOOR))

        total_units_available = sum(_whole_units(b) for b in batches)
        if total_units_available < remaining:
            total_base = sum(b.quantity for b in batches)
            detail = (
                f"Insufficient stock for {medicine.name} "
                f"(available {total_units_available} {ru.unit_name}, requested {remaining})"
            )
            if factor != 1 and total_base > 0:
                detail += (
                    f". {total_base} base units are in stock, but a whole {ru.unit_name} "
                    f"must come from a single batch — sell the remainder in the base unit"
                )
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=detail)

        for batch in batches:
            if remaining <= 0:
                break
            take_units = min(_whole_units(batch), remaining)
            if take_units <= 0:
                continue
            take_base = to_base_quantity(take_units, factor)
            unit_price = _unit_price(batch)
            batch.quantity -= take_base
            remaining -= take_units
            line_total = money(unit_price * take_units)
            sale.items.append(
                SaleItem(
                    store_id=member.store_id,
                    medicine_id=item.medicine_id,
                    stock_batch_id=batch.id,
                    unit_id=ru.unit_id,
                    quantity_in_unit=take_units,
                    quantity=take_base,
                    unit_price=unit_price,
                    line_total=line_total,
                )
            )
            subtotal += line_total

    # --- discount: user percent (%) বা flat amount, দুইভাবেই দিতে পারবে ---
    # discount_type == "percent" হলে payload.discount কে 0-100 এর মধ্যে percentage
    # হিসেবে ধরে subtotal থেকে actual টাকায় কনভার্ট করা হয়। "amount" (ডিফল্ট) হলে
    # payload.discount সরাসরি টাকার amount হিসেবে ব্যবহার হয় (আগের মতোই)।
    #
    # sale.discount কলামে সবসময় চূড়ান্ত টাকার amount-ই সেভ হয় (percent না) —
    # তাই রিপোর্ট/হিসাব-নিকাশে discount সবসময় consistent (টাকায়) থাকে, আর
    # পুরনো data-র সাথেও backward-compatible থাকে।
    if payload.discount_type == "percent":
        if payload.discount > 100:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Discount percent cannot exceed 100",
            )
        discount_amount = money(subtotal * payload.discount / Decimal("100"))
    else:
        discount_amount = money(payload.discount)

    sale.discount = discount_amount
    sale.subtotal = subtotal
    sale.total = subtotal - discount_amount
    if sale.total < 0:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Discount cannot exceed subtotal")

    sale.paid_amount = payload.paid_amount
    sale.due_amount = sale.total - payload.paid_amount
    if sale.due_amount < 0:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Paid amount cannot exceed total")

    if sale.due_amount > 0 and not (payload.customer_id or payload.customer_name or payload.customer_phone):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Customer name/phone (or customer_id) is required for due/credit sales",
        )

    db.add(sale)
    try:
        await db.flush()
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Invoice number already exists for this store, please retry",
        )

    result = await db.execute(
        select(Sale).options(selectinload(Sale.items)).where(Sale.id == sale.id)
    )
    return await _serialize_sale(db, result.scalar_one())


@router.get("", response_model=list[SaleListItemResponse])
async def list_sales(
    branch_id: Optional[int] = Query(None),
    customer_id: Optional[int] = Query(None),
    due_only: bool = Query(False),
    date_from: Optional[date] = Query(None),
    date_to: Optional[date] = Query(None),
    q: Optional[str] = Query(None, description="Search invoice no / customer name / phone"),
    limit: int = Query(50, le=200),
    offset: int = Query(0, ge=0),
    current_user: User = Depends(get_current_user),
    member: StoreMember = Depends(get_current_store_member),
    db: AsyncSession = Depends(get_db),
):
    stmt = select(Sale).where(Sale.store_id == member.store_id)

    if branch_id is not None:
        stmt = stmt.where(Sale.branch_id == branch_id)
    if customer_id is not None:
        stmt = stmt.where(Sale.customer_id == customer_id)
    if due_only:
        stmt = stmt.where(Sale.due_amount > 0)
    if date_from is not None:
        stmt = stmt.where(Sale.created_at >= date_from)
    if date_to is not None:
        stmt = stmt.where(Sale.created_at < date_to)
    if q:
        like = f"%{q}%"
        stmt = stmt.where(
            (Sale.invoice_no.ilike(like))
            | (Sale.customer_name.ilike(like))
            | (Sale.customer_phone.ilike(like))
        )

    stmt = stmt.order_by(Sale.created_at.desc()).limit(limit).offset(offset)
    result = await db.execute(stmt)
    return result.scalars().all()


@router.get("/{sale_id}", response_model=SaleResponse)
async def get_sale(
    sale_id: int,
    current_user: User = Depends(get_current_user),
    member: StoreMember = Depends(get_current_store_member),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Sale)
        .options(selectinload(Sale.items))
        .where(Sale.id == sale_id, Sale.store_id == member.store_id)
    )
    sale = result.scalar_one_or_none()
    if not sale:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Sale not found")
    return await _serialize_sale(db, sale)