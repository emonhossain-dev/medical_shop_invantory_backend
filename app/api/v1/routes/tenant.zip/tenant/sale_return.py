"""
app/routers/sale_return.py

Customer return — POST /sales/{sale_id}/items/{item_id}/return
(purchase return এর মতোই প্যাটার্ন — নির্দিষ্ট sale_item এর বিপরীতে, বিক্রি হওয়া
quantity এর বেশি return করা যাবে না, আগের return গুলোও হিসেবে ধরা হয়)।

মূল Sale/SaleItem কখনো এখানে mutate হয় না — invoice history অক্ষত থাকে।
refund সবসময় cash (business rule অনুযায়ী)।
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.depends.deps import get_current_store_member, require_permission
from app.models.all_models import Medicine, Sale, SaleItem, SaleReturn, StockBatch, StoreMember
from app.services.unit_service import money
from app.schemas.sale_return import SaleReturnCreateRequest, SaleReturnResponse

router = APIRouter(prefix="/sales", tags=["Sale Returns"])


@router.post(
    "/{sale_id}/items/{item_id}/return",
    response_model=SaleReturnResponse,
    status_code=status.HTTP_201_CREATED,
)
async def return_sale_item(
    sale_id: int,
    item_id: int,
    payload: SaleReturnCreateRequest,
    member: StoreMember = Depends(require_permission("sales", "void")),
    db: AsyncSession = Depends(get_db),
):
    row = await db.execute(
        select(SaleItem, Sale)
        .join(Sale, Sale.id == SaleItem.sale_id)
        .where(
            SaleItem.id == item_id,
            SaleItem.sale_id == sale_id,
            Sale.store_id == member.store_id,
        )
    )
    row = row.first()
    if row is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Sale item not found for this store")
    sale_item, sale = row

    already_returned = await db.scalar(
        select(func.coalesce(func.sum(SaleReturn.quantity), 0)).where(
            SaleReturn.sale_item_id == sale_item.id
        )
    )
    available = sale_item.quantity - already_returned
    if payload.quantity > available:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"এই item এ সর্বোচ্চ {available} টা return করা যাবে "
            f"(বিক্রি হয়েছিল {sale_item.quantity}, আগেই return হয়েছে {already_returned})",
        )

    # payload.quantity ও sale_item.quantity base unit-এ; কিন্তু sale_item.unit_price বিক্রির unit-এর
    # (Box হলে per Box) দাম। তাই refund = line_total-এর আনুপাতিক অংশ, আর SaleReturn.unit_price
    # = base unit প্রতি দাম (নাহলে 1 pcs return এ পুরো box এর দাম ফেরত যেত)।
    refund_amount = money(sale_item.line_total * payload.quantity / sale_item.quantity)
    base_unit_price = money(sale_item.line_total / sale_item.quantity)

    batch = None
    batch_id_to_store = None
    if payload.restock:
        target_batch_id = payload.stock_batch_id or sale_item.stock_batch_id
        if target_batch_id is None:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                "restock=true কিন্তু কোনো stock_batch_id পাওয়া যায়নি (original batch মুছে গেছে) — "
                "request এ stock_batch_id দিয়ে দাও কোন batch এ ফেরত যাবে",
            )
        batch = await db.scalar(
            select(StockBatch)
            .where(
                StockBatch.id == target_batch_id,
                StockBatch.store_id == member.store_id,
                StockBatch.branch_id == sale.branch_id,
            )
            .with_for_update()
        )
        if batch is None:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "Invalid stock_batch_id for this branch")
        batch.quantity += payload.quantity
        batch_id_to_store = batch.id

    sale_return = SaleReturn(
        store_id=member.store_id,
        branch_id=sale.branch_id,
        sale_id=sale.id,
        sale_item_id=sale_item.id,
        medicine_id=sale_item.medicine_id,
        stock_batch_id=batch_id_to_store,
        quantity=payload.quantity,
        unit_price=base_unit_price,
        refund_amount=refund_amount,
        refund_method="cash",
        restocked=payload.restock,
        notes=payload.notes,
        created_by=member.user_id,
    )
    db.add(sale_return)
    await db.commit()
    await db.refresh(sale_return)

    medicine_name = await db.scalar(select(Medicine.name).where(Medicine.id == sale_item.medicine_id))

    return SaleReturnResponse(
        id=sale_return.id,
        sale_id=sale_return.sale_id,
        sale_item_id=sale_return.sale_item_id,
        medicine_id=sale_return.medicine_id,
        medicine_name=medicine_name,
        stock_batch_id=sale_return.stock_batch_id,
        quantity=sale_return.quantity,
        unit_price=sale_return.unit_price,
        refund_amount=sale_return.refund_amount,
        refund_method=sale_return.refund_method,
        restocked=sale_return.restocked,
        notes=sale_return.notes,
        created_by=sale_return.created_by,
        created_at=sale_return.created_at,
        batch_quantity_after=batch.quantity if batch is not None else None,
    )


@router.get("/{sale_id}/returns", response_model=list[SaleReturnResponse])
async def list_sale_returns(
    sale_id: int,
    member: StoreMember = Depends(get_current_store_member),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(SaleReturn, Medicine.name)
        .join(Medicine, Medicine.id == SaleReturn.medicine_id)
        .where(SaleReturn.sale_id == sale_id, SaleReturn.store_id == member.store_id)
        .order_by(SaleReturn.created_at.desc())
    )

    return [
        SaleReturnResponse(
            id=sr.id,
            sale_id=sr.sale_id,
            sale_item_id=sr.sale_item_id,
            medicine_id=sr.medicine_id,
            medicine_name=medicine_name,
            stock_batch_id=sr.stock_batch_id,
            quantity=sr.quantity,
            unit_price=sr.unit_price,
            refund_amount=sr.refund_amount,
            refund_method=sr.refund_method,
            restocked=sr.restocked,
            notes=sr.notes,
            created_by=sr.created_by,
            created_at=sr.created_at,
            batch_quantity_after=None,
        )
        for sr, medicine_name in result.all()
    ]