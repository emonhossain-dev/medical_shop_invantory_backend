import io
import os
import re
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from fastapi.responses import StreamingResponse
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer

from app.core.database import get_db
from app.depends.deps import get_current_store_member, require_permission
from app.models.all_models import (
    Branch,
    MasterMedicine,
    Medicine,
    Purchase,
    PurchaseItem,
    StockBatch,
    Store,
    StoreMember,
    Supplier,
    StockAdjustment,
    StockAdjustmentReason,
    SupplierPayment,
    DuePaymentMethod,
    Unit,
)
from app.schemas.purchase import (
    PurchaseCreateRequest,
    PurchaseItemResponse,
    PurchaseListItemResponse,
    PurchaseResponse,
)
from app.schemas.purchase_reports import (
    PurchaseSummaryResponse,
    SupplierPaymentCreateRequest,
    SupplierPaymentResponse,
    SupplierPurchaseSummaryResponse,
)
from app.schemas.stock_adjustment import PurchaseReturnRequest, StockAdjustmentResponse
from app.services.unit_service import (
    create_medicine_with_base_unit,
    load_medicine_units,
    load_unit_map,
    money,
    price_per_base,
    price_per_unit,
    resolve_or_create_unit_for_receiving,
    to_base_quantity,
)


# NOTE: এখানে ইচ্ছাকৃতভাবে router-লেভেলে কোনো default tag রাখা হয়নি।
# প্রতিটা endpoint নিজের group অনুযায়ী আলাদা tag পাবে (নিচে দেখুন), যাতে
# Swagger UI-তে Purchases, Purchases - Invoice, Purchases - Returns,
# Purchases - Payments, Purchases - Reports — এভাবে আলাদা আলাদা section এ ভাগ হয়ে যায়।
router = APIRouter(prefix="/purchases")

TAG_CORE = "Purchases"
TAG_INVOICE = "Purchases - Invoice"
TAG_RETURNS = "Purchases - Returns"
TAG_PAYMENTS = "Purchases - Payments"
TAG_REPORTS = "Purchases - Reports"


# ---------------------------------------------------------------------------
# DATE-RANGE HELPERS — list/summary/supplier-summary/payments সবগুলোতে reuse হয়
# ---------------------------------------------------------------------------

def _apply_date_range(query, column, date_from: Optional[date], date_to: Optional[date]):
    """date_from/date_to (inclusive, ক্যালেন্ডার date হিসেবে) অনুযায়ী query তে filter বসায়।"""
    if date_from is not None:
        query = query.where(column >= datetime.combine(date_from, datetime.min.time()))
    if date_to is not None:
        query = query.where(column < datetime.combine(date_to, datetime.min.time()) + timedelta(days=1))
    return query


def _resolve_period_range(period: Optional[str]) -> tuple[Optional[date], Optional[date]]:
    """period shortcut ('today' | 'week' | 'month') কে date_from/date_to তে রূপান্তর করে।"""
    if period is None:
        return None, None
    today = datetime.utcnow().date()
    normalized = period.strip().lower()
    if normalized == "today":
        return today, today
    if normalized == "week":
        start = today - timedelta(days=today.weekday())  # সপ্তাহ শুরু সোমবার থেকে
        return start, today
    if normalized == "month":
        start = today.replace(day=1)
        return start, today
    raise HTTPException(
        status.HTTP_400_BAD_REQUEST,
        "Invalid period. Use one of: today, week, month (or use date_from/date_to instead)",
    )


# ---------------------------------------------------------------------------
# INVOICE PDF (NEW) — supplier.py এর pattern অনুসরণ করে
# ---------------------------------------------------------------------------

# PDF file গুলো এখানে save হবে -> main.py তে এই ফোল্ডারটাই StaticFiles দিয়ে mount করা আছে
INVOICE_PDF_DIR = "static/invoices/purchases"


def _safe_purchase_invoice_filename(purchase: Purchase) -> str:
    """invoice_no না থাকলে বা special character থাকলে safe filename বানানো"""
    raw = purchase.invoice_no or f"PUR-{purchase.id}"
    slug = re.sub(r"[^A-Za-z0-9_-]", "-", raw)
    return f"{slug}.pdf"


def purchase_invoice_pdf_url(request: Request, purchase: Optional[Purchase]) -> Optional[str]:
    """List/detail response-এ দেখানোর জন্য invoice PDF-এর URL বানানো (ফাইল save না করেই)।"""
    if purchase is None:
        return None
    base_url = str(request.base_url).rstrip("/")
    filename = _safe_purchase_invoice_filename(purchase)
    return f"{base_url}/static/invoices/purchases/{filename}"


def _save_purchase_invoice_pdf(request: Request, pdf_bytes: bytes, purchase: Purchase) -> str:
    """
    PDF disk-এ save করে full URL রিটার্ন করে।
    একই purchase আবার edit/regenerate হলে ফাইল overwrite হবে -> সবসময় up-to-date থাকবে।
    """
    os.makedirs(INVOICE_PDF_DIR, exist_ok=True)
    filename = _safe_purchase_invoice_filename(purchase)
    file_path = os.path.join(INVOICE_PDF_DIR, filename)

    with open(file_path, "wb") as f:
        f.write(pdf_bytes)

    base_url = str(request.base_url).rstrip("/")
    return f"{base_url}/static/invoices/purchases/{filename}"


def _build_purchase_invoice_pdf(
    store: Optional[Store],
    supplier: Optional[Supplier],
    purchase: Purchase,
    items: list[PurchaseItemResponse],
) -> bytes:
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        topMargin=18 * mm, bottomMargin=18 * mm, leftMargin=18 * mm, rightMargin=18 * mm,
    )
    styles = getSampleStyleSheet()
    story = []

    # --- Header: Store info ---
    title_style = ParagraphStyle("StoreTitle", parent=styles["Title"], fontSize=18, spaceAfter=2)
    story.append(Paragraph(store.name if store else "Store", title_style))
    if store and store.address:
        story.append(Paragraph(store.address, styles["Normal"]))
    if store and store.phone:
        story.append(Paragraph(f"Phone: {store.phone}", styles["Normal"]))
    story.append(Spacer(1, 14))

    story.append(Paragraph("PURCHASE INVOICE", ParagraphStyle("H2", parent=styles["Heading2"])))
    story.append(Spacer(1, 8))

    # --- Meta info: invoice no, date, supplier ---
    meta_data = [
        ["Invoice No:", purchase.invoice_no or f"PUR-{purchase.id}", "Date:", purchase.created_at.strftime("%d-%m-%Y")],
        ["Supplier:", supplier.name if supplier else "-", "Phone:", (supplier.phone if supplier else None) or "-"],
    ]
    meta_table = Table(meta_data, colWidths=[70, 170, 50, 150])
    meta_table.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 16))

    # --- Items table ---
    data = [["#", "Medicine", "Batch", "Qty", "Unit Price", "Line Total"]]
    for i, it in enumerate(items, 1):
        data.append([
            str(i),
            it.medicine_name or "-",
            it.batch_no or "-",
            f"{it.quantity_in_unit} {it.unit_name or ''}".strip(),
            f"{it.unit_price:.2f}",
            f"{it.line_total:.2f}",
        ])

    table = Table(data, colWidths=[20, 135, 65, 65, 75, 80])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c3e50")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ALIGN", (3, 0), (5, -1), "RIGHT"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f7f7f7")]),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(table)
    story.append(Spacer(1, 16))

    # --- Summary ---
    summary_data = [
        ["Total Amount:", f"{purchase.total_amount:.2f}"],
        ["Paid Amount:", f"{(purchase.paid_amount or 0):.2f}"],
        ["Due Amount:", f"{(purchase.due_amount or 0):.2f}"],
    ]
    summary_table = Table(summary_data, colWidths=[120, 90], hAlign="RIGHT")
    summary_table.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("FONTNAME", (0, 2), (-1, 2), "Helvetica-Bold"),
        ("LINEABOVE", (0, 2), (-1, 2), 0.75, colors.black),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.append(summary_table)
    story.append(Spacer(1, 24))
    story.append(Paragraph("This is a system-generated invoice.", ParagraphStyle("Footer", parent=styles["Normal"], fontSize=8, textColor=colors.grey)))

    doc.build(story)
    pdf_bytes = buffer.getvalue()
    buffer.close()
    return pdf_bytes


async def _load_item_responses(db: AsyncSession, purchase_id: int) -> list[PurchaseItemResponse]:
    rows = await db.execute(
        select(
            PurchaseItem,
            Medicine.name,
            StockBatch.batch_no,
            StockBatch.expiry_date,
            StockBatch.sale_price,
            Unit.name,
        )
        .join(Medicine, Medicine.id == PurchaseItem.medicine_id)
        .join(Unit, Unit.id == PurchaseItem.unit_id)
        .outerjoin(StockBatch, StockBatch.id == PurchaseItem.stock_batch_id)
        .where(PurchaseItem.purchase_id == purchase_id)
        .order_by(PurchaseItem.id)
    )
    items: list[PurchaseItemResponse] = []
    for pi, medicine_name, batch_no, expiry_date, batch_sale_price, unit_name in rows.all():
        # StockBatch.sale_price base unit-এর; purchase unit-এর দামে ফিরিয়ে দেখানো হচ্ছে।
        # factor = base quantity / unit quantity (MedicineUnit পরে বদলালেও history ঠিক থাকে)
        factor = Decimal(pi.quantity) / Decimal(pi.quantity_in_unit)
        items.append(
            PurchaseItemResponse(
                id=pi.id,
                medicine_id=pi.medicine_id,
                medicine_name=medicine_name,
                stock_batch_id=pi.stock_batch_id,
                batch_no=batch_no,
                expiry_date=expiry_date,
                unit_id=pi.unit_id,
                unit_name=unit_name,
                quantity_in_unit=pi.quantity_in_unit,
                quantity=pi.quantity,
                unit_price=pi.unit_price,
                sale_price=price_per_unit(batch_sale_price, factor) if batch_sale_price is not None else None,
                line_total=money(pi.unit_price * pi.quantity_in_unit),
            )
        )
    return items


# ---------------------------------------------------------------------------
# CREATE
# ---------------------------------------------------------------------------

@router.post("", response_model=PurchaseResponse, status_code=status.HTTP_201_CREATED, tags=[TAG_CORE])
async def create_purchase(
    request: Request,
    payload: PurchaseCreateRequest,
    member: StoreMember = Depends(require_permission("purchases", "create")),
    db: AsyncSession = Depends(get_db),
):
    store_id = member.store_id

    # --- branch validate ---
    branch = await db.scalar(
        select(Branch).where(Branch.id == payload.branch_id, Branch.store_id == store_id)
    )
    if branch is None:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Invalid branch_id for this store")

    # --- supplier validate ---
    supplier = None
    if payload.supplier_id is not None:
        supplier = await db.scalar(
            select(Supplier).where(
                Supplier.id == payload.supplier_id, Supplier.store_id == store_id
            )
        )
        if supplier is None:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "Invalid supplier_id for this store")

    # --- medicine validate + auto-create from master if needed ---
    medicine_ids = [item.medicine_id for item in payload.items]

    # FIX: age store_id filter chhilo na, tai onno store-er medicine_id
    # diyeo (bhul kore ba ichhakrito bhabe) purchase kora jeto
    result = await db.execute(
        select(Medicine).where(
            Medicine.id.in_(medicine_ids), Medicine.store_id == store_id
        )
    )
    medicines_by_id = {m.id: m for m in result.scalars().all()}

    missing_ids = set(medicine_ids) - medicines_by_id.keys()

    if missing_ids:
        master_result = await db.execute(
            select(MasterMedicine).where(
                MasterMedicine.id.in_(missing_ids),
                MasterMedicine.is_active.is_(True),
            )
        )
        masters = {m.id: m for m in master_result.scalars().all()}

        still_missing = missing_ids - masters.keys()
        if still_missing:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                f"Invalid medicine_id(s): {sorted(still_missing)}",
            )

        for master_id, master in masters.items():
            # FIX: age store_id filter chhilo na, tai onno store-er Medicine
            # row eshe jeto -> resolve_unit() sheita-r jonno "pcs is not
            # configured" error dito, karon MedicineUnit row onno store-er
            existing = await db.scalar(
                select(Medicine).where(
                    Medicine.master_medicine_id == master_id,
                    Medicine.store_id == store_id,
                )
            )
            if existing:
                medicines_by_id[master_id] = existing
            else:
                # আগে unit="pcs" hardcoded ছিল — এখন store-এর Pcs unit + base MedicineUnit row
                new_med = await create_medicine_with_base_unit(
                    db,
                    store_id,
                    name=master.brand_name,
                    generic_name=master.generic_name,
                    category=None,
                    reorder_level=10,
                    master_medicine_id=master.id,
                    is_active=True,
                )
                medicines_by_id[master_id] = new_med

    # --- unit validate + base-unit conversion ---
    # Purchase header তৈরির আগেই করা হচ্ছে, যাতে ভুল unit/quantity হলে কিছুই তৈরি না হয়।
    unit_map = await load_unit_map(db, store_id, [i.unit_id for i in payload.items])
    mu_map = await load_medicine_units(db, [medicines_by_id[i.medicine_id].id for i in payload.items])
    resolved_lines = []
    for item_in in payload.items:
        medicine = medicines_by_id[item_in.medicine_id]
        ru = await resolve_or_create_unit_for_receiving(
            db,
            store_id,
            medicine,
            item_in.unit_id,
            unit_map,
            mu_map,
            conversion_factor=item_in.conversion_factor,
            requested_medicine_id=item_in.medicine_id,
        )
        base_qty = to_base_quantity(item_in.quantity, ru.factor)  # e.g. 5 Box × 100 = 500 Pcs
        resolved_lines.append((item_in, medicine, ru, base_qty))

    # --- 1) Purchase header ---
    purchase = Purchase(
        store_id=store_id,
        branch_id=payload.branch_id,
        supplier_id=payload.supplier_id,
        total_amount=Decimal("0"),
        paid_amount=Decimal("0"),
        due_amount=Decimal("0"),
        created_by=member.user_id,
    )
    db.add(purchase)
    await db.flush()

    purchase.invoice_no = f"PUR-{purchase.id:06d}"

    total_amount = Decimal("0")
    item_responses: list[PurchaseItemResponse] = []

    # --- 2 & 3) Items + StockBatch ---
    for item_in, medicine, ru, base_qty in resolved_lines:
        # StockBatch সবসময় base unit-এ: quantity ও দাম দুটোই base unit অনুযায়ী।
        # request-এর unit_price / sale_price "ঐ unit_id-এর" দাম (per Box ইত্যাদি)।
        batch = StockBatch(
            store_id=store_id,
            branch_id=payload.branch_id,
            medicine_id=medicine.id,
            batch_no=item_in.batch_no,
            quantity=base_qty,
            purchase_price=price_per_base(item_in.unit_price, ru.factor),
            sale_price=price_per_base(item_in.sale_price, ru.factor),
            expiry_date=item_in.expiry_date,
        )
        db.add(batch)
        await db.flush()

        line_total = money(item_in.unit_price * item_in.quantity)
        purchase_item = PurchaseItem(
            purchase_id=purchase.id,
            store_id=store_id,
            medicine_id=medicine.id,
            stock_batch_id=batch.id,
            unit_id=ru.unit_id,
            quantity_in_unit=item_in.quantity,
            quantity=base_qty,
            unit_price=item_in.unit_price,
        )
        db.add(purchase_item)
        await db.flush()

        total_amount += line_total

        item_responses.append(
            PurchaseItemResponse(
                id=purchase_item.id,
                medicine_id=medicine.id,
                medicine_name=medicine.name,
                stock_batch_id=batch.id,
                batch_no=batch.batch_no,
                expiry_date=batch.expiry_date,
                unit_id=ru.unit_id,
                unit_name=ru.unit_name,
                quantity_in_unit=item_in.quantity,
                quantity=base_qty,
                unit_price=item_in.unit_price,
                sale_price=item_in.sale_price,
                line_total=line_total,
            )
        )

    # --- 4) total + payment হিসাব ---
    paid_amount = payload.paid_amount or Decimal("0")
    if paid_amount > total_amount:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"paid_amount ({paid_amount}) cannot be greater than total_amount ({total_amount})",
        )

    due_amount = total_amount - paid_amount

    purchase.total_amount = total_amount
    purchase.paid_amount = paid_amount
    purchase.due_amount = due_amount

    # --- 5) যদি payment করা হয়, SupplierPayment তৈরি করো ---
    if paid_amount > 0 and payload.supplier_id is not None:
        from app.models.all_models import DuePaymentMethod  # যদি উপরে import না থাকে

        method = DuePaymentMethod.cash
        if payload.payment_method:
            try:
                method = DuePaymentMethod(payload.payment_method.lower())
            except ValueError:
                method = DuePaymentMethod.other

        supplier_payment = SupplierPayment(
            store_id=store_id,
            supplier_id=payload.supplier_id,
            purchase_id=purchase.id,
            amount=paid_amount,
            method=method,
            reference_no=payload.payment_reference,
            note=payload.payment_note,
            paid_by=member.user_id,
        )
        db.add(supplier_payment)

    # --- 6) Commit ---
    await db.commit()
    await db.refresh(purchase)

    # --- PDF generate ---
    store = await db.get(Store, store_id)
    pdf_bytes = _build_purchase_invoice_pdf(store, supplier, purchase, item_responses)
    pdf_url = _save_purchase_invoice_pdf(request, pdf_bytes, purchase)

    return PurchaseResponse(
        id=purchase.id,
        store_id=store_id,
        branch_id=purchase.branch_id,
        supplier_id=purchase.supplier_id,
        supplier_name=supplier.name if supplier else None,
        invoice_no=purchase.invoice_no,
        total_amount=total_amount,
        paid_amount=paid_amount,
        due_amount=due_amount,
        created_by=purchase.created_by,
        created_at=purchase.created_at,
        items=item_responses,
        pdf_url=pdf_url,
    )

# ---------------------------------------------------------------------------
# LIST
# ---------------------------------------------------------------------------

@router.get("", response_model=list[PurchaseListItemResponse], tags=[TAG_CORE])
async def list_purchases(
    request: Request,
    branch_id: int | None = Query(default=None),
    supplier_id: int | None = Query(default=None),
    date_from: Optional[date] = Query(default=None, description="YYYY-MM-DD (inclusive)"),
    date_to: Optional[date] = Query(default=None, description="YYYY-MM-DD (inclusive)"),
    member: StoreMember = Depends(get_current_store_member),
    db: AsyncSession = Depends(get_db),
):
    """
    সব purchase-এর list — branch/supplier দিয়ে filter করা যায়, এবং এখন date_from/date_to
    দিয়েও filter করা যায় (যেমন: শুধু আজকের বা এই মাসের purchase বের করতে)।
    """
    item_count_subq = (
        select(func.count(PurchaseItem.id))
        .where(PurchaseItem.purchase_id == Purchase.id)
        .correlate(Purchase)
        .scalar_subquery()
    )

    query = (
        select(
            Purchase,
            Supplier.name.label("supplier_name"),
            item_count_subq.label("item_count"),
        )
        .outerjoin(Supplier, Supplier.id == Purchase.supplier_id)
        .where(Purchase.store_id == member.store_id)
        .order_by(Purchase.created_at.desc())
    )

    if branch_id is not None:
        query = query.where(Purchase.branch_id == branch_id)
    if supplier_id is not None:
        query = query.where(Purchase.supplier_id == supplier_id)
    query = _apply_date_range(query, Purchase.created_at, date_from, date_to)

    result = await db.execute(query)

    return [
        PurchaseListItemResponse(
            id=row.Purchase.id,
            branch_id=row.Purchase.branch_id,
            supplier_id=row.Purchase.supplier_id,
            supplier_name=row.supplier_name,
            invoice_no=row.Purchase.invoice_no,
            total_amount=row.Purchase.total_amount,
            item_count=row.item_count,
            created_at=row.Purchase.created_at,
            pdf_url=purchase_invoice_pdf_url(request, row.Purchase),
        )
        for row in result.all()
    ]


# ---------------------------------------------------------------------------
# DETAIL
# ---------------------------------------------------------------------------

@router.get("/{purchase_id}", response_model=PurchaseResponse, tags=[TAG_CORE])
async def get_purchase(
    request: Request,
    purchase_id: int,
    member: StoreMember = Depends(get_current_store_member),
    db: AsyncSession = Depends(get_db),
):
    purchase = await db.scalar(
        select(Purchase).where(
            Purchase.id == purchase_id, Purchase.store_id == member.store_id
        )
    )
    if purchase is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Purchase not found")

    supplier_name = None
    if purchase.supplier_id is not None:
        supplier_name = await db.scalar(
            select(Supplier.name).where(Supplier.id == purchase.supplier_id)
        )

    items = await _load_item_responses(db, purchase.id)

    return PurchaseResponse(
        id=purchase.id,
        store_id=purchase.store_id,
        branch_id=purchase.branch_id,
        supplier_id=purchase.supplier_id,
        supplier_name=supplier_name,
        invoice_no=purchase.invoice_no,
        total_amount=purchase.total_amount,
        created_by=purchase.created_by,
        created_at=purchase.created_at,
        items=items,
        pdf_url=purchase_invoice_pdf_url(request, purchase),
    )


# ---------------------------------------------------------------------------
# INVOICE PDF DOWNLOAD
# ---------------------------------------------------------------------------

@router.get("/{purchase_id}/invoice/pdf", tags=[TAG_INVOICE])
async def download_purchase_invoice_pdf(
    request: Request,
    purchase_id: int,
    member: StoreMember = Depends(get_current_store_member),
    db: AsyncSession = Depends(get_db),
):
    """নির্দিষ্ট purchase-এর invoice PDF সরাসরি download/view করার API (supplier.py এর invoice pdf endpoint এর মতো)।"""
    purchase = await db.scalar(
        select(Purchase).where(
            Purchase.id == purchase_id, Purchase.store_id == member.store_id
        )
    )
    if purchase is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Purchase not found")

    supplier = None
    if purchase.supplier_id is not None:
        supplier = await db.get(Supplier, purchase.supplier_id)

    store = await db.get(Store, member.store_id)

    items = await _load_item_responses(db, purchase.id)

    pdf_bytes = _build_purchase_invoice_pdf(store, supplier, purchase, items)

    filename = f"invoice-{purchase.invoice_no or purchase.id}.pdf"
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f'inline; filename="{filename}"'},
    )


# ---------------------------------------------------------------------------
# PURCHASE RETURN — supplier কে stock ফেরত (partial return সাপোর্ট করে)
# ---------------------------------------------------------------------------

@router.post(
    "/{purchase_id}/items/{item_id}/return",
    response_model=StockAdjustmentResponse,
    status_code=status.HTTP_201_CREATED,
    tags=[TAG_RETURNS],
)
async def return_purchase_item(
    purchase_id: int,
    item_id: int,
    payload: PurchaseReturnRequest,
    member: StoreMember = Depends(require_permission("stock", "adjust")),
    db: AsyncSession = Depends(get_db),
):
    """
    একটা purchase item এর নির্দিষ্ট quantity সাপ্লায়ারকে ফেরত।
    Partial return সাপোর্ট করে (পুরো quantity ফেরত না দিয়ে অংশ দেওয়া যায়)।

    NOTE (unit): payload.quantity সবসময় base unit-এ (StockBatch.quantity / item.quantity এর মতোই)।
    StockAdjustment.unit_price = base unit-এর purchase price (batch.purchase_price) — item.unit_price
    নয়, কারণ সেটা purchase unit-এর (Box ইত্যাদি) দাম।

    Rule: এখনো stock এ যতটুকু বাকি আছে (StockBatch.quantity) তার বেশি ফেরত দেওয়া যাবে না
    — কারণ ইতিমধ্যে বিক্রি হয়ে যাওয়া quantity ফেরত দেওয়ার কোনো মানে নেই।

    Concurrency: batch row FOR UPDATE লক করা হয় already_returned গণনার আগেই —
    একই batch এ একসাথে দুইটা return/sale এলে দ্বিতীয়টা প্রথমটার commit পর্যন্ত
    wait করবে, ফলে stale quantity দিয়ে হিসাব হওয়ার সুযোগ থাকে না।
    """
    purchase = await db.scalar(
        select(Purchase).where(
            Purchase.id == purchase_id, Purchase.store_id == member.store_id
        )
    )
    if purchase is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Purchase not found")

    item = await db.scalar(
        select(PurchaseItem).where(
            PurchaseItem.id == item_id, PurchaseItem.purchase_id == purchase.id
        )
    )
    if item is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Purchase item not found")

    if item.stock_batch_id is None:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "This item has no linked stock batch")

    # --- FIX: row lock নেওয়া হচ্ছে এখানে, already_returned গণনার আগেই ---
    batch = await db.scalar(
        select(StockBatch)
        .where(StockBatch.id == item.stock_batch_id)
        .with_for_update()
    )
    if batch is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Stock batch not found")

    # ইতিমধ্যে কতটুকু return হয়ে গেছে এই item থেকে — সেটা হিসাব করে বাকি returnable বের করা
    already_returned = await db.scalar(
        select(func.coalesce(func.sum(-StockAdjustment.quantity_change), 0)).where(
            StockAdjustment.purchase_item_id == item.id,
            StockAdjustment.reason == StockAdjustmentReason.purchase_return,
        )
    )
    max_returnable = min(batch.quantity, item.quantity - already_returned)

    if payload.quantity > max_returnable:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"Cannot return {payload.quantity} — max returnable right now is {max_returnable} "
            f"(current batch stock: {batch.quantity}, already returned: {already_returned})",
        )

    batch.quantity -= payload.quantity

    adjustment = StockAdjustment(
        store_id=member.store_id,
        branch_id=purchase.branch_id,
        medicine_id=item.medicine_id,
        stock_batch_id=batch.id,
        reason=StockAdjustmentReason.purchase_return,
        quantity_change=-payload.quantity,
        unit_price=batch.purchase_price,
        purchase_id=purchase.id,
        purchase_item_id=item.id,
        notes=payload.notes,
        created_by=member.user_id,
    )
    db.add(adjustment)
    await db.commit()
    await db.refresh(adjustment)

    medicine_name = await db.scalar(select(Medicine.name).where(Medicine.id == item.medicine_id))

    return StockAdjustmentResponse(
        id=adjustment.id,
        branch_id=adjustment.branch_id,
        medicine_id=adjustment.medicine_id,
        medicine_name=medicine_name,
        stock_batch_id=adjustment.stock_batch_id,
        batch_no=batch.batch_no,
        reason=adjustment.reason,
        quantity_change=adjustment.quantity_change,
        unit_price=adjustment.unit_price,
        purchase_id=adjustment.purchase_id,
        purchase_item_id=adjustment.purchase_item_id,
        notes=adjustment.notes,
        created_by=adjustment.created_by,
        created_at=adjustment.created_at,
        batch_quantity_after=batch.quantity,
    )

# ---------------------------------------------------------------------------
# PAYMENTS — supplier due এর বিপরীতে নতুন payment রেকর্ড করা + payment history
# ---------------------------------------------------------------------------

def _serialize_payment(
    payment: SupplierPayment,
    supplier_name: Optional[str],
    invoice_no: Optional[str],
) -> SupplierPaymentResponse:
    method_value = payment.method.value if hasattr(payment.method, "value") else str(payment.method)
    return SupplierPaymentResponse(
        id=payment.id,
        store_id=payment.store_id,
        supplier_id=payment.supplier_id,
        supplier_name=supplier_name,
        purchase_id=payment.purchase_id,
        invoice_no=invoice_no,
        amount=payment.amount,
        method=method_value,
        reference_no=payment.reference_no,
        note=payment.note,
        paid_by=payment.paid_by,
        created_at=payment.created_at,
    )


@router.post(
    "/{purchase_id}/payments",
    response_model=SupplierPaymentResponse,
    status_code=status.HTTP_201_CREATED,
    tags=[TAG_PAYMENTS],
)
async def add_purchase_payment(
    purchase_id: int,
    payload: SupplierPaymentCreateRequest,
    member: StoreMember = Depends(require_permission("suppliers", "update")),
    db: AsyncSession = Depends(get_db),
):
    """
    কোনো purchase-এর বাকি due-এর বিপরীতে নতুন payment রেকর্ড করা।
    যেমন: purchase করার সময় partial payment করা হয়েছিল, এখন বাকি due partial/পুরোপুরি শোধ করা হচ্ছে।

    Rule: payment amount, বর্তমান due_amount থেকে বেশি হতে পারবে না।
    """
    purchase = await db.scalar(
        select(Purchase).where(Purchase.id == purchase_id, Purchase.store_id == member.store_id)
    )
    if purchase is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Purchase not found")

    if purchase.supplier_id is None:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "This purchase has no supplier linked — cannot record a supplier payment against it",
        )

    current_due = purchase.due_amount or Decimal("0")
    if payload.amount > current_due:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"Payment amount ({payload.amount}) is more than the current due ({current_due})",
        )

    method = DuePaymentMethod.cash
    if payload.method:
        try:
            method = DuePaymentMethod(payload.method.lower())
        except ValueError:
            method = DuePaymentMethod.other

    payment = SupplierPayment(
        store_id=member.store_id,
        supplier_id=purchase.supplier_id,
        purchase_id=purchase.id,
        amount=payload.amount,
        method=method,
        reference_no=payload.reference_no,
        note=payload.note,
        paid_by=member.user_id,
    )
    db.add(payment)

    purchase.paid_amount = (purchase.paid_amount or Decimal("0")) + payload.amount
    purchase.due_amount = current_due - payload.amount

    await db.commit()
    await db.refresh(payment)
    await db.refresh(purchase)

    supplier_name = await db.scalar(select(Supplier.name).where(Supplier.id == purchase.supplier_id))

    return _serialize_payment(payment, supplier_name, purchase.invoice_no)


@router.get(
    "/{purchase_id}/payments",
    response_model=list[SupplierPaymentResponse],
    tags=[TAG_PAYMENTS],
)
async def list_purchase_payments(
    purchase_id: int,
    member: StoreMember = Depends(get_current_store_member),
    db: AsyncSession = Depends(get_db),
):
    """একটা নির্দিষ্ট purchase-এর বিপরীতে এখন পর্যন্ত যত payment হয়েছে, তার list।"""
    purchase = await db.scalar(
        select(Purchase).where(Purchase.id == purchase_id, Purchase.store_id == member.store_id)
    )
    if purchase is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Purchase not found")

    rows = await db.execute(
        select(SupplierPayment, Supplier.name.label("supplier_name"))
        .outerjoin(Supplier, Supplier.id == SupplierPayment.supplier_id)
        .where(SupplierPayment.purchase_id == purchase.id)
        .order_by(SupplierPayment.created_at.desc())
    )

    return [
        _serialize_payment(payment, supplier_name, purchase.invoice_no)
        for payment, supplier_name in rows.all()
    ]


@router.get(
    "/payments/history",
    response_model=list[SupplierPaymentResponse],
    tags=[TAG_PAYMENTS],
)
async def list_all_payments(
    supplier_id: Optional[int] = Query(default=None),
    date_from: Optional[date] = Query(default=None, description="YYYY-MM-DD (inclusive)"),
    date_to: Optional[date] = Query(default=None, description="YYYY-MM-DD (inclusive)"),
    member: StoreMember = Depends(get_current_store_member),
    db: AsyncSession = Depends(get_db),
):
    """
    পুরো store-এর সব supplier payment এর history — এক জায়গায়।
    supplier_id দিয়ে filter করলে "একজন সাপ্লায়ারকে এ পর্যন্ত কত/কবে কবে পেমেন্ট দিলাম" বের করা যায়,
    date_from/date_to দিয়ে "এই মাসে মোট কত পেমেন্ট দিলাম" জাতীয় প্রশ্নেরও উত্তর পাওয়া যায়।
    """
    query = (
        select(SupplierPayment, Supplier.name.label("supplier_name"), Purchase.invoice_no)
        .outerjoin(Supplier, Supplier.id == SupplierPayment.supplier_id)
        .outerjoin(Purchase, Purchase.id == SupplierPayment.purchase_id)
        .where(SupplierPayment.store_id == member.store_id)
        .order_by(SupplierPayment.created_at.desc())
    )
    if supplier_id is not None:
        query = query.where(SupplierPayment.supplier_id == supplier_id)
    query = _apply_date_range(query, SupplierPayment.created_at, date_from, date_to)

    rows = await db.execute(query)

    return [
        _serialize_payment(payment, supplier_name, invoice_no)
        for payment, supplier_name, invoice_no in rows.all()
    ]


# ---------------------------------------------------------------------------
# REPORTS — overall summary + supplier-wise summary/history
# ---------------------------------------------------------------------------

@router.get(
    "/reports/summary",
    response_model=PurchaseSummaryResponse,
    tags=[TAG_REPORTS],
)
async def get_purchase_summary(
    period: Optional[str] = Query(
        default=None, description="Shortcut: today | week | month. দেওয়া থাকলে এবং date_from/date_to না দিলে সেটাই ব্যবহার হবে।"
    ),
    date_from: Optional[date] = Query(default=None, description="YYYY-MM-DD (inclusive)"),
    date_to: Optional[date] = Query(default=None, description="YYYY-MM-DD (inclusive)"),
    branch_id: Optional[int] = Query(default=None),
    supplier_id: Optional[int] = Query(default=None),
    member: StoreMember = Depends(get_current_store_member),
    db: AsyncSession = Depends(get_db),
):
    """
    এক নজরে: নির্দিষ্ট সময়ে (আজ/এই সপ্তাহ/এই মাস/custom range) মোট কয়টা purchase হয়েছে,
    মোট টাকার purchase, মোট paid, মোট due — কত।

    উদাহরণ: /purchases/reports/summary?period=month
            /purchases/reports/summary?date_from=2026-09-01&date_to=2026-09-24
    """
    if date_from is None and date_to is None and period is not None:
        date_from, date_to = _resolve_period_range(period)

    query = select(
        func.count(Purchase.id),
        func.coalesce(func.sum(Purchase.total_amount), 0),
        func.coalesce(func.sum(Purchase.paid_amount), 0),
        func.coalesce(func.sum(Purchase.due_amount), 0),
    ).where(Purchase.store_id == member.store_id)

    if branch_id is not None:
        query = query.where(Purchase.branch_id == branch_id)
    if supplier_id is not None:
        query = query.where(Purchase.supplier_id == supplier_id)
    query = _apply_date_range(query, Purchase.created_at, date_from, date_to)

    count, total_amount, total_paid, total_due = (await db.execute(query)).one()

    return PurchaseSummaryResponse(
        date_from=date_from,
        date_to=date_to,
        total_purchase_count=count,
        total_amount=total_amount,
        total_paid=total_paid,
        total_due=total_due,
    )


@router.get(
    "/suppliers/{supplier_id}/summary",
    response_model=SupplierPurchaseSummaryResponse,
    tags=[TAG_REPORTS],
)
async def get_supplier_purchase_summary(
    request: Request,
    supplier_id: int,
    date_from: Optional[date] = Query(default=None, description="YYYY-MM-DD (inclusive)"),
    date_to: Optional[date] = Query(default=None, description="YYYY-MM-DD (inclusive)"),
    branch_id: Optional[int] = Query(default=None),
    member: StoreMember = Depends(get_current_store_member),
    db: AsyncSession = Depends(get_db),
):
    """
    একটা নির্দিষ্ট supplier থেকে এ পর্যন্ত কী কী purchase করা হয়েছে — full history,
    সাথে সেই supplier-এর total purchase / total paid / total due — একসাথে।
    """
    supplier = await db.scalar(
        select(Supplier).where(Supplier.id == supplier_id, Supplier.store_id == member.store_id)
    )
    if supplier is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Supplier not found")

    item_count_subq = (
        select(func.count(PurchaseItem.id))
        .where(PurchaseItem.purchase_id == Purchase.id)
        .correlate(Purchase)
        .scalar_subquery()
    )

    query = (
        select(Purchase, item_count_subq.label("item_count"))
        .where(Purchase.store_id == member.store_id, Purchase.supplier_id == supplier_id)
        .order_by(Purchase.created_at.desc())
    )
    if branch_id is not None:
        query = query.where(Purchase.branch_id == branch_id)
    query = _apply_date_range(query, Purchase.created_at, date_from, date_to)

    rows = (await db.execute(query)).all()

    purchases = [
        PurchaseListItemResponse(
            id=row.Purchase.id,
            branch_id=row.Purchase.branch_id,
            supplier_id=row.Purchase.supplier_id,
            supplier_name=supplier.name,
            invoice_no=row.Purchase.invoice_no,
            total_amount=row.Purchase.total_amount,
            item_count=row.item_count,
            created_at=row.Purchase.created_at,
            pdf_url=purchase_invoice_pdf_url(request, row.Purchase),
        )
        for row in rows
    ]

    total_amount = sum((row.Purchase.total_amount or Decimal("0") for row in rows), Decimal("0"))
    total_paid = sum((row.Purchase.paid_amount or Decimal("0") for row in rows), Decimal("0"))
    total_due = sum((row.Purchase.due_amount or Decimal("0") for row in rows), Decimal("0"))

    return SupplierPurchaseSummaryResponse(
        supplier_id=supplier.id,
        supplier_name=supplier.name,
        total_purchase_count=len(purchases),
        total_amount=total_amount,
        total_paid=total_paid,
        total_due=total_due,
        purchases=purchases,
    )