import random
from datetime import datetime
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.database import get_db
from app.depends.deps import get_current_store_member, get_current_user, require_permission
from app.models.all_models import (
    Branch,
    Customer,
    HoldSale,
    HoldSaleItem,
    Medicine,
    Sale,
    SaleItem,
    StockBatch,
    StoreMember,
    User,
)
from app.schemas.hold_sale import (
    HoldSaleCreateRequest,
    HoldSaleItemResponse,
    HoldSaleListItemResponse,
    HoldSaleResponse,
    HoldSaleUpdateRequest,
    ResumeHoldSaleRequest,
)
from app.schemas.sale import SaleResponse

router = APIRouter(prefix="/sales/hold", tags=["Sales / POS - Hold Bills"])


# ---------------------------------------------------------------------------
# Permission notes:
# create_sale এর মতোই "sales" module ব্যবহার করা হয়েছে। Hold করা ==
# বিক্রি শুরু করা, তাই যে cashier/pharmacist sale create করতে পারে সেই
# hold ও করতে পারবে। যদি আপনার permission seed এ এই codes না থাকে,
# সেগুলো Permission টেবিলে যোগ করে owner role এ link করে দিন:
#   sales:create  -> hold create/update, resume (আসল sale বানায়)
#   sales:view    -> hold list/get
#   sales:delete  -> hold discard
# ---------------------------------------------------------------------------


def _line_total(quantity: int, unit_price: Optional[Decimal]) -> Optional[Decimal]:
    if unit_price is None:
        return None
    return (unit_price * quantity).quantize(Decimal("0.01"))


async def _attach_medicine_names(db: AsyncSession, items: list[HoldSaleItem]) -> dict[int, str]:
    if not items:
        return {}
    ids = {item.medicine_id for item in items}
    result = await db.execute(select(Medicine.id, Medicine.name).where(Medicine.id.in_(ids)))
    return {row.id: row.name for row in result.all()}


def _estimate_totals(hold: HoldSale, names: dict[int, str]) -> tuple[list[HoldSaleItemResponse], Decimal, Decimal]:
    item_responses = []
    subtotal = Decimal("0")
    for item in hold.items:
        line_total = _line_total(item.quantity, item.unit_price)
        if line_total is not None:
            subtotal += line_total
        item_responses.append(
            HoldSaleItemResponse(
                id=item.id,
                medicine_id=item.medicine_id,
                medicine_name=names.get(item.medicine_id),
                stock_batch_id=item.stock_batch_id,
                quantity=item.quantity,
                unit_price=item.unit_price,
                line_total=line_total,
            )
        )
    total = subtotal - hold.discount
    if total < 0:
        total = Decimal("0")
    return item_responses, subtotal, total


async def _to_response(db: AsyncSession, hold: HoldSale) -> HoldSaleResponse:
    names = await _attach_medicine_names(db, hold.items)
    item_responses, subtotal, total = _estimate_totals(hold, names)
    return HoldSaleResponse(
        id=hold.id,
        store_id=hold.store_id,
        branch_id=hold.branch_id,
        label=hold.label,
        customer_id=hold.customer_id,
        customer_name=hold.customer_name,
        customer_phone=hold.customer_phone,
        discount=hold.discount,
        note=hold.note,
        held_by=hold.held_by,
        created_at=hold.created_at,
        updated_at=hold.updated_at,
        resumed_sale_id=hold.resumed_sale_id,
        items=item_responses,
        estimated_subtotal=subtotal,
        estimated_total=total,
    )


async def _get_hold_or_404(db: AsyncSession, hold_id: int, store_id: int) -> HoldSale:
    result = await db.execute(
        select(HoldSale)
        .options(selectinload(HoldSale.items))
        .where(HoldSale.id == hold_id, HoldSale.store_id == store_id)
    )
    hold = result.scalar_one_or_none()
    if hold is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Hold bill not found")
    return hold


def _ensure_not_resumed(hold: HoldSale) -> None:
    if hold.resumed_sale_id is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="This hold bill has already been resumed into a sale",
        )


async def _validate_branch_and_customer(
    db: AsyncSession, store_id: int, branch_id: int, customer_id: Optional[int]
) -> None:
    branch = await db.get(Branch, branch_id)
    if not branch or branch.store_id != store_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Branch not found")

    if customer_id is not None:
        customer = await db.get(Customer, customer_id)
        if not customer or customer.store_id != store_id:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Customer not found")


async def _validate_items(db: AsyncSession, store_id: int, items) -> None:
    for item in items:
        medicine = await db.get(Medicine, item.medicine_id)
        if not medicine or medicine.store_id != store_id or not medicine.is_active:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Medicine {item.medicine_id} not found",
            )
        if item.stock_batch_id is not None:
            batch = await db.get(StockBatch, item.stock_batch_id)
            if not batch or batch.store_id != store_id or batch.medicine_id != item.medicine_id:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Stock batch {item.stock_batch_id} not found for medicine {item.medicine_id}",
                )


# ---------------------------------------------------------------------------
# CREATE
# ---------------------------------------------------------------------------

@router.post("", response_model=HoldSaleResponse, status_code=status.HTTP_201_CREATED)
async def create_hold_sale(
    payload: HoldSaleCreateRequest,
    current_user: User = Depends(get_current_user),
    member: StoreMember = Depends(require_permission("sales", "create")),
    db: AsyncSession = Depends(get_db),
):
    """
    বিল hold করে রাখে — কোনো stock deduct হয় না। POS-এ customer wait করলে
    বা cashier হুট করে অন্য customer ধরলে, চলতি বিলটা এখানে সরিয়ে রেখে
    পরে `POST /sales/hold/{id}/resume` দিয়ে checkout সম্পূর্ণ করা যাবে।
    """
    await _validate_branch_and_customer(db, member.store_id, payload.branch_id, payload.customer_id)
    await _validate_items(db, member.store_id, payload.items)

    hold = HoldSale(
        store_id=member.store_id,
        branch_id=payload.branch_id,
        label=payload.label,
        customer_id=payload.customer_id,
        customer_name=payload.customer_name,
        customer_phone=payload.customer_phone,
        discount=payload.discount,
        note=payload.note,
        held_by=current_user.id,
    )
    hold.items = [
        HoldSaleItem(
            store_id=member.store_id,
            medicine_id=item.medicine_id,
            stock_batch_id=item.stock_batch_id,
            quantity=item.quantity,
            unit_price=item.unit_price,
        )
        for item in payload.items
    ]

    db.add(hold)
    await db.flush()
    await db.commit()

    hold = await _get_hold_or_404(db, hold.id, member.store_id)
    return await _to_response(db, hold)


# ---------------------------------------------------------------------------
# LIST
# ---------------------------------------------------------------------------

@router.get("", response_model=list[HoldSaleListItemResponse])
async def list_hold_sales(
    branch_id: Optional[int] = Query(None),
    include_resumed: bool = Query(False, description="True হলে resume হয়ে যাওয়া hold-ও দেখাবে (history)"),
    current_user: User = Depends(get_current_user),
    member: StoreMember = Depends(require_permission("sales", "view")),
    db: AsyncSession = Depends(get_db),
):
    """POS-এর 'Held Bills' প্যানেলের জন্য — active hold গুলোর সংক্ষিপ্ত তালিকা।"""
    stmt = select(HoldSale).options(selectinload(HoldSale.items)).where(HoldSale.store_id == member.store_id)

    if branch_id is not None:
        stmt = stmt.where(HoldSale.branch_id == branch_id)
    elif member.branch_id is not None:
        # branch-bound staff শুধু নিজের branch-এর hold গুলোই দেখবে
        stmt = stmt.where(HoldSale.branch_id == member.branch_id)

    if not include_resumed:
        stmt = stmt.where(HoldSale.resumed_sale_id.is_(None))

    stmt = stmt.order_by(HoldSale.created_at.desc())
    result = await db.execute(stmt)
    holds = list(result.scalars().unique().all())

    responses = []
    for hold in holds:
        names = await _attach_medicine_names(db, hold.items)
        _, _, total = _estimate_totals(hold, names)
        responses.append(
            HoldSaleListItemResponse(
                id=hold.id,
                branch_id=hold.branch_id,
                label=hold.label,
                customer_name=hold.customer_name,
                customer_phone=hold.customer_phone,
                discount=hold.discount,
                item_count=len(hold.items),
                estimated_total=total,
                held_by=hold.held_by,
                created_at=hold.created_at,
                updated_at=hold.updated_at,
            )
        )
    return responses


# ---------------------------------------------------------------------------
# GET ONE
# ---------------------------------------------------------------------------

@router.get("/{hold_id}", response_model=HoldSaleResponse)
async def get_hold_sale(
    hold_id: int,
    current_user: User = Depends(get_current_user),
    member: StoreMember = Depends(require_permission("sales", "view")),
    db: AsyncSession = Depends(get_db),
):
    hold = await _get_hold_or_404(db, hold_id, member.store_id)
    return await _to_response(db, hold)


# ---------------------------------------------------------------------------
# UPDATE (edit items / discount / customer while still on hold)
# ---------------------------------------------------------------------------

@router.put("/{hold_id}", response_model=HoldSaleResponse)
async def update_hold_sale(
    hold_id: int,
    payload: HoldSaleUpdateRequest,
    current_user: User = Depends(get_current_user),
    member: StoreMember = Depends(require_permission("sales", "create")),
    db: AsyncSession = Depends(get_db),
):
    hold = await _get_hold_or_404(db, hold_id, member.store_id)
    _ensure_not_resumed(hold)

    if payload.customer_id is not None or payload.customer_name is not None or payload.customer_phone is not None:
        await _validate_branch_and_customer(db, member.store_id, hold.branch_id, payload.customer_id)

    if payload.label is not None:
        hold.label = payload.label
    if payload.customer_id is not None:
        hold.customer_id = payload.customer_id
    if payload.customer_name is not None:
        hold.customer_name = payload.customer_name
    if payload.customer_phone is not None:
        hold.customer_phone = payload.customer_phone
    if payload.discount is not None:
        hold.discount = payload.discount
    if payload.note is not None:
        hold.note = payload.note

    if payload.items is not None:
        await _validate_items(db, member.store_id, payload.items)
        hold.items = [
            HoldSaleItem(
                store_id=member.store_id,
                medicine_id=item.medicine_id,
                stock_batch_id=item.stock_batch_id,
                quantity=item.quantity,
                unit_price=item.unit_price,
            )
            for item in payload.items
        ]

    hold.updated_at = datetime.utcnow()
    await db.flush()
    await db.commit()

    hold = await _get_hold_or_404(db, hold_id, member.store_id)
    return await _to_response(db, hold)


# ---------------------------------------------------------------------------
# DISCARD
# ---------------------------------------------------------------------------

@router.delete("/{hold_id}", status_code=status.HTTP_204_NO_CONTENT)
async def discard_hold_sale(
    hold_id: int,
    current_user: User = Depends(get_current_user),
    member: StoreMember = Depends(require_permission("sales", "delete")),
    db: AsyncSession = Depends(get_db),
):
    """Hold বিলটা বাতিল করে — কোনো stock touch হয়নি বলে ফেরত দেওয়ার কিছু নেই, শুধু row মুছে যায়।"""
    hold = await _get_hold_or_404(db, hold_id, member.store_id)
    _ensure_not_resumed(hold)

    await db.delete(hold)
    await db.commit()


# ---------------------------------------------------------------------------
# RESUME -> creates a real Sale (mirrors Sale.py's create_sale FEFO logic)
# ---------------------------------------------------------------------------

def _generate_invoice_no(store_id: int, branch_id: int) -> str:
    suffix = "".join(random.choices("0123456789", k=4))
    return f"INV-{store_id}{branch_id}-{datetime.utcnow():%y%m%d}-{suffix}"


async def _get_available_batches(
    db: AsyncSession, store_id: int, branch_id: int, medicine_id: int, lock: bool = False
) -> list[StockBatch]:
    """FEFO order — Sale.py এর _get_available_batches এর হুবহু কপি, hold resume এর জন্য দরকার।"""
    stmt = (
        select(StockBatch)
        .where(
            StockBatch.store_id == store_id,
            StockBatch.branch_id == branch_id,
            StockBatch.medicine_id == medicine_id,
            StockBatch.quantity > 0,
        )
        .order_by(
            StockBatch.expiry_date.is_(None),
            StockBatch.expiry_date.asc(),
            StockBatch.received_at.asc(),
        )
    )
    if lock:
        stmt = stmt.with_for_update()
    result = await db.execute(stmt)
    return list(result.scalars().all())


@router.post("/{hold_id}/resume", response_model=SaleResponse, status_code=status.HTTP_201_CREATED)
async def resume_hold_sale(
    hold_id: int,
    payload: ResumeHoldSaleRequest,
    current_user: User = Depends(get_current_user),
    member: StoreMember = Depends(require_permission("sales", "create")),
    db: AsyncSession = Depends(get_db),
):
    """
    Hold বিলটাকে checkout করে আসল Sale বানায়। Stock allocation এখানেই প্রথমবার
    হয় (FEFO, ঠিক create_sale এর মতো) — hold করে রাখার সময় কোনো batch
    reserve করা হয়নি, তাই মাঝে অন্য sale সেই stock নিয়ে নিলে এখানে
    "insufficient stock" error আসতে পারে; cashier তখন item edit করে আবার
    resume করবে।
    """
    hold = await _get_hold_or_404(db, hold_id, member.store_id)
    _ensure_not_resumed(hold)
    if not hold.items:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Hold bill has no items")

    branch = await db.get(Branch, hold.branch_id)
    if not branch or branch.store_id != member.store_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Branch not found")

    if hold.customer_id is not None:
        customer = await db.get(Customer, hold.customer_id)
        if not customer or customer.store_id != member.store_id:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Customer not found")

    sale = Sale(
        store_id=member.store_id,
        branch_id=hold.branch_id,
        invoice_no=payload.invoice_no or _generate_invoice_no(member.store_id, hold.branch_id),
        customer_id=hold.customer_id,
        customer_name=hold.customer_name,
        customer_phone=hold.customer_phone,
        discount=hold.discount,
        sold_by=current_user.id,
    )

    subtotal = Decimal("0")

    for item in hold.items:
        medicine = await db.get(Medicine, item.medicine_id)
        if not medicine or medicine.store_id != member.store_id or not medicine.is_active:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Medicine {item.medicine_id} not found",
            )

        remaining = item.quantity

        if item.stock_batch_id is not None:
            batch = await db.get(StockBatch, item.stock_batch_id, with_for_update=True)
            if (
                not batch
                or batch.store_id != member.store_id
                or batch.branch_id != hold.branch_id
                or batch.medicine_id != item.medicine_id
            ):
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Stock batch {item.stock_batch_id} not found for this medicine/branch",
                )
            if batch.quantity < remaining:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=(
                        f"Insufficient stock in batch {batch.id} for {medicine.name} "
                        f"(available {batch.quantity}, requested {remaining})"
                    ),
                )
            unit_price = item.unit_price if item.unit_price is not None else batch.sale_price
            batch.quantity -= remaining
            line_total = (unit_price * remaining).quantize(Decimal("0.01"))
            sale.items.append(
                SaleItem(
                    store_id=member.store_id,
                    medicine_id=item.medicine_id,
                    stock_batch_id=batch.id,
                    quantity=remaining,
                    unit_price=unit_price,
                    line_total=line_total,
                )
            )
            subtotal += line_total
            continue

        batches = await _get_available_batches(db, member.store_id, hold.branch_id, item.medicine_id, lock=True)
        total_available = sum(b.quantity for b in batches)
        if total_available < remaining:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    f"Insufficient stock for {medicine.name} "
                    f"(available {total_available}, requested {remaining})"
                ),
            )

        for batch in batches:
            if remaining <= 0:
                break
            take = min(batch.quantity, remaining)
            unit_price = item.unit_price if item.unit_price is not None else batch.sale_price
            batch.quantity -= take
            remaining -= take
            line_total = (unit_price * take).quantize(Decimal("0.01"))
            sale.items.append(
                SaleItem(
                    store_id=member.store_id,
                    medicine_id=item.medicine_id,
                    stock_batch_id=batch.id,
                    quantity=take,
                    unit_price=unit_price,
                    line_total=line_total,
                )
            )
            subtotal += line_total

    sale.subtotal = subtotal
    sale.total = subtotal - sale.discount
    if sale.total < 0:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Discount cannot exceed subtotal")

    sale.paid_amount = payload.paid_amount
    sale.due_amount = sale.total - payload.paid_amount
    if sale.due_amount < 0:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Paid amount cannot exceed total")

    if sale.due_amount > 0 and not (sale.customer_id or sale.customer_name or sale.customer_phone):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Customer name/phone (or customer_id) is required for due/credit sales",
        )

    db.add(sale)
    try:
        await db.flush()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Invoice number already exists for this store, please retry",
        )

    hold.resumed_sale_id = sale.id
    await db.commit()

    result = await db.execute(select(Sale).options(selectinload(Sale.items)).where(Sale.id == sale.id))
    return result.scalar_one()