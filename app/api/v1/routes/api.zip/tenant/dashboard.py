# app/api/dashboard.py
from datetime import date
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.depends.deps import get_current_store_member
from app.models.all_models import StaffRole, StoreMember
from app.schemas.dashboard import DashboardResponse
from app.services.dashboard_service import DashboardService, today_bd

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])

MAX_RANGE_DAYS = 366


@router.get("", response_model=DashboardResponse)
async def get_dashboard(
    date_from: Optional[date] = Query(None, description="Default: আজ (Asia/Dhaka)"),
    date_to: Optional[date] = Query(None, description="Default: আজ (Asia/Dhaka)"),
    db: AsyncSession = Depends(get_db),
    member: StoreMember = Depends(get_current_store_member),
):
    """
    Store dashboard — daily sales, customer due, supplier due, stock alerts
    এবং pie chart data।

    - কোনো date না দিলে শুধু আজকের data আসবে।
    - branch-bound staff (member.branch_id সেট) শুধু নিজের branch এর data দেখবে।
    - owner/manager store-wide সব branch এর data দেখবে।
    - estimated_gross_profit শুধু owner/manager এর জন্য।
    """
    d_from = date_from or date_to or today_bd()
    d_to = date_to or d_from

    if d_from > d_to:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="date_from must be on or before date_to",
        )
    if (d_to - d_from).days + 1 > MAX_RANGE_DAYS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Date range cannot exceed {MAX_RANGE_DAYS} days",
        )

    service = DashboardService(
        db=db,
        store_id=member.store_id,
        branch_id=member.branch_id,
        can_see_profit=member.role in (StaffRole.owner, StaffRole.manager),
    )
    return await service.build(d_from, d_to)