import re
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.database import get_db
from app.core.permissions import PERMISSION_CATALOG, MODULE_LABELS, iter_permission_codes
from app.depends.deps import require_store_admin, require_owner, get_current_store_member
from app.models.all_models import Role, RolePermission, Permission, StoreMember, Branch
from app.schemas.rbac import (
    PermissionOut, RoleIn, RoleUpdateIn, RoleOut, StaffAssignIn, StaffOut,
)

router = APIRouter(prefix="", tags=["roles"])


def slugify(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", name.strip().lower()).strip("-")


# ---------------------------------------------------------------------------
# Permission catalog (read-only reference)
# ---------------------------------------------------------------------------

@router.get("/roles/permissions", response_model=dict[str, list[PermissionOut]])
async def list_permission_catalog(
    member: StoreMember = Depends(get_current_store_member),
):
    """Module wise grouped catalog — role তৈরির form এ checkbox list বানাতে দরকার হবে।"""
    grouped: dict[str, list[PermissionOut]] = {}
    for module, action, code in iter_permission_codes():
        grouped.setdefault(module, []).append(
            PermissionOut(code=code, module=module, action=action,
                          label=f"{MODULE_LABELS.get(module, module)} — {action}")
        )
    return grouped


# ---------------------------------------------------------------------------
# Roles CRUD — শুধু owner/manager (require_store_admin)
# ---------------------------------------------------------------------------

@router.get("/roles", response_model=list[RoleOut])
async def list_roles(
    member: StoreMember = Depends(require_store_admin),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Role)
        .options(selectinload(Role.permission_links).selectinload(RolePermission.permission))
        .where(Role.store_id == member.store_id)
        .order_by(Role.id)
    )
    roles = result.scalars().all()
    return [
        RoleOut(
            id=r.id, name=r.name, slug=r.slug, description=r.description, is_system=r.is_system,
            permission_codes=sorted(link.permission.code for link in r.permission_links),
        )
        for r in roles
    ]


@router.post("/roles", response_model=RoleOut, status_code=status.HTTP_201_CREATED)
async def create_role(
    payload: RoleIn,
    member: StoreMember = Depends(require_store_admin),
    db: AsyncSession = Depends(get_db),
):
    slug = slugify(payload.name)
    if slug in ("owner",):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, detail="এই নামে role বানানো যাবে না")

    exists = await db.execute(
        select(Role).where(Role.store_id == member.store_id, Role.name == payload.name)
    )
    if exists.scalar_one_or_none():
        raise HTTPException(status.HTTP_409_CONFLICT, detail="এই নামে role আগে থেকেই আছে")

    valid_codes = {code for _, _, code in iter_permission_codes()}
    bad = set(payload.permission_codes) - valid_codes
    if bad:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, detail=f"Invalid permission code(s): {sorted(bad)}")

    role = Role(store_id=member.store_id, name=payload.name, slug=slug,
                description=payload.description, is_system=False)
    db.add(role)
    await db.flush()

    if payload.permission_codes:
        perms = (await db.execute(select(Permission).where(Permission.code.in_(payload.permission_codes)))).scalars().all()
        db.add_all([RolePermission(role_id=role.id, permission_id=p.id) for p in perms])
        await db.flush()

    await db.refresh(role, attribute_names=["permission_links"])
    return RoleOut(
        id=role.id, name=role.name, slug=role.slug, description=role.description, is_system=role.is_system,
        permission_codes=sorted(payload.permission_codes),
    )


@router.patch("/roles/{role_id}", response_model=RoleOut)
async def update_role(
    role_id: int,
    payload: RoleUpdateIn,
    member: StoreMember = Depends(require_store_admin),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Role)
        .options(selectinload(Role.permission_links).selectinload(RolePermission.permission))
        .where(Role.id == role_id, Role.store_id == member.store_id)
    )
    role = result.scalar_one_or_none()
    if role is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail="Role not found")
    if role.is_system:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, detail="System role (Owner) edit করা যাবে না")

    if payload.name is not None:
        role.name = payload.name
        role.slug = slugify(payload.name)
    if payload.description is not None:
        role.description = payload.description

    if payload.permission_codes is not None:
        valid_codes = {code for _, _, code in iter_permission_codes()}
        bad = set(payload.permission_codes) - valid_codes
        if bad:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, detail=f"Invalid permission code(s): {sorted(bad)}")

        for link in list(role.permission_links):
            await db.delete(link)
        await db.flush()

        perms = (await db.execute(select(Permission).where(Permission.code.in_(payload.permission_codes)))).scalars().all()
        db.add_all([RolePermission(role_id=role.id, permission_id=p.id) for p in perms])

    await db.flush()
    await db.refresh(role, attribute_names=["permission_links"])
    return RoleOut(
        id=role.id, name=role.name, slug=role.slug, description=role.description, is_system=role.is_system,
        permission_codes=sorted(link.permission.code for link in role.permission_links),
    )


@router.delete("/roles/{role_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_role(
    role_id: int,
    member: StoreMember = Depends(require_store_admin),
    db: AsyncSession = Depends(get_db),
):
    role = (await db.execute(select(Role).where(Role.id == role_id, Role.store_id == member.store_id))).scalar_one_or_none()
    if role is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail="Role not found")
    if role.is_system:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, detail="System role (Owner) ডিলিট করা যাবে না")

    in_use = (await db.execute(select(StoreMember).where(StoreMember.role_id == role_id))).first()
    if in_use:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, detail="এই role এ staff assigned আছে, আগে তাদের অন্য role এ সরান")

    await db.delete(role)
    await db.flush()


# ---------------------------------------------------------------------------
# Staff: role + branch assignment
# ---------------------------------------------------------------------------

@router.get("/staff", response_model=list[StaffOut])
async def list_staff(
    member: StoreMember = Depends(require_store_admin),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(StoreMember)
        .options(selectinload(StoreMember.role))
        .where(StoreMember.store_id == member.store_id)
        .order_by(StoreMember.id)
    )
    rows = result.scalars().all()
    return [
        StaffOut(id=m.id, user_id=m.user_id, role_id=m.role_id, role_name=m.role.name,
                 branch_id=m.branch_id, is_active=m.is_active)
        for m in rows
    ]


@router.patch("/staff/{member_id}", response_model=StaffOut)
async def assign_staff_role_and_branch(
    member_id: int,
    payload: StaffAssignIn,
    admin: StoreMember = Depends(require_store_admin),
    db: AsyncSession = Depends(get_db),
):
    """
    এখানেই মূল কাজটা হয়:
      - role_id দিয়ে ঠিক করে দিচ্ছেন এই staff কোন permission set পাবে
      - branch_id দিয়ে ঠিক করে দিচ্ছেন সে কোন branch-এ bound (None = store-wide)
    """
    target = (await db.execute(
        select(StoreMember).options(selectinload(StoreMember.role))
        .where(StoreMember.id == member_id, StoreMember.store_id == admin.store_id)
    )).scalar_one_or_none()
    if target is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail="Staff member not found")

    if target.role.is_system and target.role.slug == "owner":
        raise HTTPException(status.HTTP_400_BAD_REQUEST, detail="Owner এর role/branch এভাবে বদলানো যাবে না")

    new_role = (await db.execute(
        select(Role).where(Role.id == payload.role_id, Role.store_id == admin.store_id)
    )).scalar_one_or_none()
    if new_role is None:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, detail="Invalid role_id")
    if new_role.is_system and new_role.slug == "owner":
        raise HTTPException(status.HTTP_400_BAD_REQUEST, detail="আরেকজনকে Owner role assign করা যাবে না")

    if payload.branch_id is not None:
        branch = (await db.execute(
            select(Branch).where(Branch.id == payload.branch_id, Branch.store_id == admin.store_id)
        )).scalar_one_or_none()
        if branch is None:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, detail="Invalid branch_id")

    target.role_id = new_role.id
    target.branch_id = payload.branch_id
    await db.flush()
    await db.refresh(target, attribute_names=["role"])

    return StaffOut(id=target.id, user_id=target.user_id, role_id=target.role_id, role_name=target.role.name,
                     branch_id=target.branch_id, is_active=target.is_active)